package com.example.opsc_part2.model

data class Category (
    val categoryName: String,
    val tag: String
        )