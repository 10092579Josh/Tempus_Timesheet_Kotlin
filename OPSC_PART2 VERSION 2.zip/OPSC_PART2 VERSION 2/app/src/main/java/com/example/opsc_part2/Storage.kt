package com.example.opsc_part2

data class Storage(

    val stuff:String


)
data class tasks
    ( val tasks:String

            )

data class catergories
    (
    val catname:String,
    val cathours : String,
    val userid:String
            )
data class User(
    val name: String,
    val surname: String,
    val usersname: String,
    val email: String,
    val password: String,
    val confirm: String,


)